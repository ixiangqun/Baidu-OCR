__version__ = "1.0.0"
__author__ = "Your Name"
__email__ = "your.email@example.com"
__description__ = "基于百度OCR的完整文字识别解决方案，成功率99.1%"
__license__ = "MIT"
__url__ = "https://github.com/yourusername/ocr-baidu-processor"
__keywords__ = ["OCR", "百度OCR", "文字识别", "批量处理", "图像处理"]